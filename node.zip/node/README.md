---
layout: post
title: "Web Project (Node)"
comments: true
description: "Web Devlopment"
keywords: "Devlopment"
---

---
# Description <br>
이번 프로젝트는 node.js를 이용한 웹 서비스 개발 프로젝트 입니다. 웹 서비스의 배경은 페이스북/인스타그램과 같은 sns 서비스와 상품을 파는 쇼핑몰 서비스 입니다.

---

# Things used<br>
Language&nbsp;&nbsp;&nbsp;`HTML`, `Javascript`<br>
Database&nbsp;&nbsp;&nbsp;&nbsp;`MySQL`, `Mongo DB`<br>
OS&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;`Ubuntu`<br>
WF&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;`Node.js`


---
# Project Member
`pocas`<br>

---
# Project period<br>
undefined

---
